from PyQt6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout,
                                    QLabel, QLineEdit, QPushButton,
                                    QMessageBox, QRadioButton, QButtonGroup,
                                    QStackedWidget)
from PyQt6.QtCore import pyqtSignal, Qt

class ForgotPasswordView(QWidget):
    """Forgot password window view"""
    
    # Signals
    find_account = pyqtSignal(str, str)  # type, value
    verify_otp = pyqtSignal(str)  # otp
    reset_password = pyqtSignal(str)  # new_password
    
    def __init__(self):
        super().__init__()
        self.init_ui()
        
    def init_ui(self):
        """Initialize the user interface"""
        self.setWindowTitle('Quên mật khẩu')
        self.setFixedSize(400, 300)
        
        # Create layouts
        main_layout = QVBoxLayout()
        
        # Create stacked widget for different steps
        self.stacked_widget = QStackedWidget()
        
        # First page - Find account
        find_account_widget = self.create_find_account_page()
        
        # Second page - Verify OTP
        verify_otp_widget = self.create_verify_otp_page()
        
        # Third page - Reset password
        reset_password_widget = self.create_reset_password_page()
        
        # Add pages to stacked widget
        self.stacked_widget.addWidget(find_account_widget)
        self.stacked_widget.addWidget(verify_otp_widget)
        self.stacked_widget.addWidget(reset_password_widget)
        
        # Add stacked widget to main layout
        main_layout.addWidget(self.stacked_widget)
        
        # Set main layout
        self.setLayout(main_layout)
        
    def create_find_account_page(self):
        """Create find account page"""
        find_account_widget = QWidget()
        find_account_layout = QVBoxLayout()
        
        title_label = QLabel('Tìm tài khoản của bạn')
        title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title_label.setStyleSheet('font-size: 18px; font-weight: bold; margin: 10px;')
        
        # Radio buttons for search type
        self.email_radio = QRadioButton('Tìm bằng Email')
        self.phone_radio = QRadioButton('Tìm bằng số điện thoại')
        self.email_radio.setChecked(True)
        
        button_group = QButtonGroup()
        button_group.addButton(self.email_radio)
        button_group.addButton(self.phone_radio)
        
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText('Nhập email')
        
        self.find_button = QPushButton('Tìm kiếm')
        self.find_button.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                border: none;
                padding: 8px;
                border-radius: 4px;
            }
            QPushButton:hover {
                background-color: #45a049;
            }
        """)
        
        cancel_button = QPushButton('Hủy')
        cancel_button.setStyleSheet("""
            QPushButton {
                background-color: #f44336;
                color: white;
                border: none;
                padding: 8px;
                border-radius: 4px;
            }
            QPushButton:hover {
                background-color: #da190b;
            }
        """)
        
        # Add widgets to layout
        find_account_layout.addWidget(title_label)
        find_account_layout.addWidget(self.email_radio)
        find_account_layout.addWidget(self.phone_radio)
        find_account_layout.addWidget(self.search_input)
        
        button_layout = QHBoxLayout()
        button_layout.addWidget(self.find_button)
        button_layout.addWidget(cancel_button)
        find_account_layout.addLayout(button_layout)
        
        find_account_widget.setLayout(find_account_layout)
        
        # Connect signals
        self.email_radio.toggled.connect(self.update_placeholder)
        self.find_button.clicked.connect(self.handle_find_account)
        cancel_button.clicked.connect(self.close)
        
        return find_account_widget
        
    def create_verify_otp_page(self):
        """Create verify OTP page"""
        verify_otp_widget = QWidget()
        verify_otp_layout = QVBoxLayout()
        
        title_label = QLabel('Xác thực mã OTP')
        title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title_label.setStyleSheet('font-size: 18px; font-weight: bold; margin: 10px;')
        
        info_label = QLabel('Chúng tôi đã gửi mã xác thực đến email của bạn')
        info_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        self.otp_input = QLineEdit()
        self.otp_input.setPlaceholderText('Nhập mã xác thực')
        self.otp_input.setMaxLength(6)
        
        verify_button = QPushButton('Xác thực')
        verify_button.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                border: none;
                padding: 8px;
                border-radius: 4px;
            }
            QPushButton:hover {
                background-color: #45a049;
            }
        """)
        
        back_button = QPushButton('Quay lại')
        back_button.setStyleSheet("""
            QPushButton {
                background-color: #2196F3;
                color: white;
                border: none;
                padding: 8px;
                border-radius: 4px;
            }
            QPushButton:hover {
                background-color: #1976D2;
            }
        """)
        
        # Add widgets to layout
        verify_otp_layout.addWidget(title_label)
        verify_otp_layout.addWidget(info_label)
        verify_otp_layout.addWidget(self.otp_input)
        
        button_layout = QHBoxLayout()
        button_layout.addWidget(verify_button)
        button_layout.addWidget(back_button)
        verify_otp_layout.addLayout(button_layout)
        
        verify_otp_widget.setLayout(verify_otp_layout)
        
        # Connect signals
        verify_button.clicked.connect(self.handle_verify_otp)
        back_button.clicked.connect(lambda: self.stacked_widget.setCurrentIndex(0))
        
        return verify_otp_widget
        
    def create_reset_password_page(self):
        """Create reset password page"""
        reset_password_widget = QWidget()
        reset_password_layout = QVBoxLayout()
        
        reset_title = QLabel('Đặt lại mật khẩu')
        reset_title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        reset_title.setStyleSheet('font-size: 18px; font-weight: bold; margin: 10px;')
        
        self.new_password_input = QLineEdit()
        self.new_password_input.setPlaceholderText('Nhập mật khẩu mới')
        self.new_password_input.setEchoMode(QLineEdit.EchoMode.Password)
        
        self.confirm_password_input = QLineEdit()
        self.confirm_password_input.setPlaceholderText('Xác nhận mật khẩu mới')
        self.confirm_password_input.setEchoMode(QLineEdit.EchoMode.Password)
        
        self.reset_button = QPushButton('Đặt lại mật khẩu')
        self.reset_button.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                border: none;
                padding: 8px;
                border-radius: 4px;
            }
            QPushButton:hover {
                background-color: #45a049;
            }
        """)
        
        back_button = QPushButton('Quay lại')
        back_button.setStyleSheet("""
            QPushButton {
                background-color: #2196F3;
                color: white;
                border: none;
                padding: 8px;
                border-radius: 4px;
            }
            QPushButton:hover {
                background-color: #1976D2;
            }
        """)
        
        # Add widgets to layout
        reset_password_layout.addWidget(reset_title)
        reset_password_layout.addWidget(self.new_password_input)
        reset_password_layout.addWidget(self.confirm_password_input)
        
        button_layout = QHBoxLayout()
        button_layout.addWidget(self.reset_button)
        button_layout.addWidget(back_button)
        reset_password_layout.addLayout(button_layout)
        
        reset_password_widget.setLayout(reset_password_layout)
        
        # Connect signals
        self.reset_button.clicked.connect(self.handle_reset_password)
        back_button.clicked.connect(lambda: self.stacked_widget.setCurrentIndex(1))
        
        return reset_password_widget
        
    def update_placeholder(self):
        """Update input placeholder based on selected search type"""
        if self.email_radio.isChecked():
            self.search_input.setPlaceholderText('Nhập email')
        else:
            self.search_input.setPlaceholderText('Nhập số điện thoại')
            
    def handle_find_account(self):
        """Handle find account button click"""
        search_value = self.search_input.text().strip()
        if not search_value:
            QMessageBox.warning(
                self,
                'Lỗi',
                'Vui lòng nhập email hoặc số điện thoại.'
            )
            return
            
        search_type = 'email' if self.email_radio.isChecked() else 'phone'
        self.find_account.emit(search_type, search_value)
        
    def handle_verify_otp(self):
        """Handle verify OTP button click"""
        otp = self.otp_input.text().strip()
        if not otp or len(otp) != 6:
            QMessageBox.warning(
                self,
                'Lỗi',
                'Vui lòng nhập mã xác thực 6 số.'
            )
            return
            
        self.verify_otp.emit(otp)
        
    def handle_reset_password(self):
        """Handle reset password button click"""
        new_password = self.new_password_input.text()
        confirm_password = self.confirm_password_input.text()
        
        if not new_password or not confirm_password:
            QMessageBox.warning(
                self,
                'Lỗi',
                'Vui lòng nhập đầy đủ thông tin.'
            )
            return
            
        if new_password != confirm_password:
            QMessageBox.warning(
                self,
                'Lỗi',
                'Mật khẩu xác nhận không khớp.'
            )
            return
            
        self.reset_password.emit(new_password)
        
    def show_otp_page(self):
        """Show the OTP verification page"""
        self.stacked_widget.setCurrentIndex(1)
        self.otp_input.clear()
        self.otp_input.setFocus()
        
    def show_reset_password_page(self):
        """Show the reset password page"""
        self.stacked_widget.setCurrentIndex(2)
        self.new_password_input.clear()
        self.confirm_password_input.clear()
        self.new_password_input.setFocus()
        
    def show_success(self, message):
        """Show success message"""
        QMessageBox.information(self, 'Thành công', message)
        
    def show_error(self, message):
        """Show error message"""
        QMessageBox.critical(self, 'Lỗi', message)
        
    def clear_fields(self):
        """Clear all input fields"""
        self.search_input.clear()
        self.otp_input.clear()
        self.new_password_input.clear()
        self.confirm_password_input.clear()
        self.stacked_widget.setCurrentIndex(0)
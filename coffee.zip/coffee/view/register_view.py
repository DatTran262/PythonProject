from PyQt6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, 
                                    QLabel, QLineEdit, QPushButton, 
                                    QMessageBox)
from PyQt6.QtCore import pyqtSignal, Qt

class RegisterView(QWidget):
    """Registration window view"""
    
    # Signal emitted when registration is successful
    register_successful = pyqtSignal(dict)

    def __init__(self):
        super().__init__()
        self.init_ui()

    def init_ui(self):
        """Initialize the user interface"""
        self.setWindowTitle('Coffee Shop Management - Register')
        self.setFixedSize(400, 300)

        # Create layouts
        main_layout = QVBoxLayout()
        form_layout = QVBoxLayout()
        button_layout = QHBoxLayout()

        # Create widgets
        title_label = QLabel('Register New Account')
        title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title_label.setStyleSheet('font-size: 18px; font-weight: bold; margin: 10px;')

        self.username_label = QLabel('Username:')
        self.username_input = QLineEdit()
        self.username_input.setPlaceholderText('Enter username')

        self.password_label = QLabel('Password:')
        self.password_input = QLineEdit()
        self.password_input.setPlaceholderText('Enter password')
        self.password_input.setEchoMode(QLineEdit.EchoMode.Password)

        self.confirm_password_label = QLabel('Confirm Password:')
        self.confirm_password_input = QLineEdit()
        self.confirm_password_input.setPlaceholderText('Confirm password')
        self.confirm_password_input.setEchoMode(QLineEdit.EchoMode.Password)

        self.register_button = QPushButton('Register')
        self.register_button.setFixedWidth(100)
        self.register_button.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                border: none;
                padding: 8px;
                border-radius: 4px;
            }
            QPushButton:hover {
                background-color: #45a049;
            }
        """)

        self.back_button = QPushButton('Back to Login')
        self.back_button.setFixedWidth(100)
        self.back_button.setStyleSheet("""
            QPushButton {
                background-color: #2196F3;
                color: white;
                border: none;
                padding: 8px;
                border-radius: 4px;
            }
            QPushButton:hover {
                background-color: #1976D2;
            }
        """)

        # Add widgets to layouts
        form_layout.addWidget(title_label)
        form_layout.addWidget(self.username_label)
        form_layout.addWidget(self.username_input)
        form_layout.addWidget(self.password_label)
        form_layout.addWidget(self.password_input)
        form_layout.addWidget(self.confirm_password_label)
        form_layout.addWidget(self.confirm_password_input)

        button_layout.addStretch()
        button_layout.addWidget(self.register_button)
        button_layout.addWidget(self.back_button)
        button_layout.addStretch()

        # Add layouts to main layout
        main_layout.addLayout(form_layout)
        main_layout.addLayout(button_layout)

        # Set main layout
        self.setLayout(main_layout)

        # Connect signals
        self.register_button.clicked.connect(self.handle_register_click)
        self.back_button.clicked.connect(self.close)
        self.confirm_password_input.returnPressed.connect(self.handle_register_click)

        # Set tab order
        self.setTabOrder(self.username_input, self.password_input)
        self.setTabOrder(self.password_input, self.confirm_password_input)
        self.setTabOrder(self.confirm_password_input, self.register_button)
        self.setTabOrder(self.register_button, self.back_button)

    def handle_register_click(self):
        """Handle register button click"""
        username = self.username_input.text().strip()
        password = self.password_input.text().strip()
        confirm_password = self.confirm_password_input.text().strip()

        if not username or not password or not confirm_password:
            QMessageBox.warning(
                self,
                'Registration Error',
                'Please fill in all fields.'
            )
            return

        if password != confirm_password:
            QMessageBox.warning(
                self,
                'Registration Error',
                'Passwords do not match.'
            )
            self.password_input.clear()
            self.confirm_password_input.clear()
            self.password_input.setFocus()
            return

        # Emit signal with registration data
        self.emit_register_attempt(username, password)

    def emit_register_attempt(self, username, password):
        """Emit registration data"""
        self.register_successful.emit({
            'username': username,
            'password': password,
            'role': 'staff'  # Default role for new registrations
        })

    def show_error(self, message):
        """Show error message box"""
        QMessageBox.critical(
            self,
            'Registration Error',
            message
        )

    def show_success(self, message):
        """Show success message box"""
        QMessageBox.information(
            self,
            'Registration Successful',
            message
        )

    def clear_fields(self):
        """Clear input fields"""
        self.username_input.clear()
        self.password_input.clear()
        self.confirm_password_input.clear()
        self.username_input.setFocus()
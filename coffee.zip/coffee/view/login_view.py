from PyQt6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, 
                                    QLabel, QLineEdit, QPushButton, 
                                    QMessageBox)
from PyQt6.QtCore import pyqtSignal, Qt

class LoginView(QWidget):
    """Login window view"""
    
    # Signal emitted when login is successful
    login_successful = pyqtSignal(dict)
    # Signal emitted when register button is clicked
    register_clicked = pyqtSignal()
    forgot_password_clicked = pyqtSignal()

    def __init__(self):
        super().__init__()
        self.init_ui()

    def init_ui(self):
        """Initialize the user interface"""
        self.setWindowTitle('Coffee Shop Management - Login')
        self.setFixedSize(400, 250)

        # Create layouts
        main_layout = QVBoxLayout()
        form_layout = QVBoxLayout()
        button_layout = QHBoxLayout()
        register_layout = QHBoxLayout()

        # Create widgets
        title_label = QLabel('Coffee Shop Management')
        title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title_label.setStyleSheet('font-size: 18px; font-weight: bold; margin: 10px;')

        self.username_label = QLabel('Username:')
        self.username_input = QLineEdit()
        self.username_input.setPlaceholderText('Enter username')

        self.password_label = QLabel('Password:')
        self.password_input = QLineEdit()
        self.password_input.setPlaceholderText('Enter password')
        self.password_input.setEchoMode(QLineEdit.EchoMode.Password)

        self.login_button = QPushButton('Login')
        self.login_button.setFixedWidth(100)
        self.login_button.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                border: none;
                padding: 8px;
                border-radius: 4px;
            }
            QPushButton:hover {
                background-color: #45a049;
            }
        """)

        self.exit_button = QPushButton('Exit')
        self.exit_button.setFixedWidth(100)
        self.exit_button.setStyleSheet("""
            QPushButton {
                background-color: #f44336;
                color: white;
                border: none;
                padding: 8px;
                border-radius: 4px;
            }
            QPushButton:hover {
                background-color: #da190b;
            }
        """)

        # Add register and forgot password section
        register_label = QLabel("Don't have an account?")
        self.register_button = QPushButton('Register')
        self.register_button.setFixedWidth(100)
        self.register_button.setStyleSheet("""
            QPushButton {
                background-color: #2196F3;
                color: white;
                border: none;
                padding: 8px;
                border-radius: 4px;
            }
            QPushButton:hover {
                background-color: #1976D2;
            }
        """)

        self.forgot_password_button = QPushButton('Quên mật khẩu')
        self.forgot_password_button.setFixedWidth(100)
        self.forgot_password_button.setStyleSheet("""
            QPushButton {
                background-color: #FF9800;
                color: white;
                border: none;
                padding: 8px;
                border-radius: 4px;
            }
            QPushButton:hover {
                background-color: #F57C00;
            }
        """)

        # Add widgets to layouts
        form_layout.addWidget(title_label)
        form_layout.addWidget(self.username_label)
        form_layout.addWidget(self.username_input)
        form_layout.addWidget(self.password_label)
        form_layout.addWidget(self.password_input)

        button_layout.addStretch()
        button_layout.addWidget(self.login_button)
        button_layout.addWidget(self.exit_button)
        button_layout.addStretch()

        register_layout.addStretch()
        register_layout.addWidget(register_label)
        register_layout.addWidget(self.register_button)
        register_layout.addWidget(self.forgot_password_button)
        register_layout.addStretch()

        # Add layouts to main layout
        main_layout.addLayout(form_layout)
        main_layout.addLayout(button_layout)
        main_layout.addLayout(register_layout)

        # Set main layout
        self.setLayout(main_layout)

        # Connect signals
        self.login_button.clicked.connect(self.handle_login_click)
        self.exit_button.clicked.connect(self.close)
        self.register_button.clicked.connect(self.register_clicked.emit)
        self.forgot_password_button.clicked.connect(self.forgot_password_clicked.emit)
        self.password_input.returnPressed.connect(self.handle_login_click)

        # Set tab order
        self.setTabOrder(self.username_input, self.password_input)
        self.setTabOrder(self.password_input, self.login_button)
        self.setTabOrder(self.login_button, self.exit_button)
        self.setTabOrder(self.exit_button, self.register_button)

    def handle_login_click(self):
        """Handle login button click"""
        username = self.username_input.text().strip()
        password = self.password_input.text().strip()

        if not username or not password:
            QMessageBox.warning(
                self,
                'Login Error',
                'Please enter both username and password.'
            )
            return

        # Emit signal with credentials for controller to handle
        self.emit_login_attempt(username, password)

    def emit_login_attempt(self, username, password):
        """Emit login credentials for controller"""
        self.login_successful.emit({
            'username': username,
            'password': password
        })

    def show_error(self, message):
        """Show error message box"""
        QMessageBox.critical(
            self,
            'Login Error',
            message
        )

    def clear_fields(self):
        """Clear input fields"""
        self.username_input.clear()
        self.password_input.clear()
        self.username_input.setFocus()
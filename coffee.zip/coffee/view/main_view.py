from PyQt6.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, 
                                    QHBoxLayout, QPushButton, QLabel, 
                                    QStackedWidget, QMenuBar, QMenu, 
                                    QStatusBar, QMessageBox)
from PyQt6.QtCore import Qt

class MainView(QMainWindow):
    def __init__(self):
        super().__init__()
        self.init_ui()

    def init_ui(self):
        """Initialize the user interface"""
        self.setWindowTitle('Coffee Shop Management System')
        self.setMinimumSize(1024, 768)

        # Create central widget and main layout
        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)
        self.main_layout = QVBoxLayout(self.central_widget)

        # Create menu bar
        self.create_menu_bar()

        # Create header
        self.create_header()

        # Create main content area
        self.create_content_area()

        # Create status bar
        self.statusBar = QStatusBar()
        self.setStatusBar(self.statusBar)

        # Set window properties
        self.setStyleSheet("""
            QMainWindow {
                background-color: #f5f5f5;
            }
            QPushButton {
                padding: 8px 15px;
                border-radius: 4px;
                background-color: #4CAF50;
                color: white;
                border: none;
                min-width: 100px;
            }
            QPushButton:hover {
                background-color: #45a049;
            }
            QLabel {
                color: #333;
            }
            #headerLabel {
                font-size: 24px;
                font-weight: bold;
                color: #2c3e50;
                padding: 10px;
            }
            #userLabel {
                font-size: 14px;
                color: #666;
            }
        """)

    def create_menu_bar(self):
        """Create the menu bar"""
        menubar = self.menuBar()

        # File menu
        file_menu = menubar.addMenu('&File')
        
        self.logout_action = file_menu.addAction('Logout')
        file_menu.addSeparator()
        self.exit_action = file_menu.addAction('Exit')

        # Management menu
        self.management_menu = menubar.addMenu('&Management')
        self.users_action = self.management_menu.addAction('Users')
        self.menu_items_action = self.management_menu.addAction('Menu Items')
        
        # Orders menu
        orders_menu = menubar.addMenu('&Orders')
        self.new_order_action = orders_menu.addAction('New Order')
        self.view_orders_action = orders_menu.addAction('View Orders')

        # Reports menu
        reports_menu = menubar.addMenu('&Reports')
        self.daily_report_action = reports_menu.addAction('Daily Report')
        self.weekly_report_action = reports_menu.addAction('Weekly Report')
        self.monthly_report_action = reports_menu.addAction('Monthly Report')

    def create_header(self):
        """Create the header section"""
        header_layout = QHBoxLayout()

        self.header_label = QLabel('Coffee Shop Management System')
        self.header_label.setObjectName('headerLabel')
        self.header_label.setAlignment(Qt.AlignmentFlag.AlignLeft)

        self.user_label = QLabel()
        self.user_label.setObjectName('userLabel')
        self.user_label.setAlignment(Qt.AlignmentFlag.AlignRight)

        header_layout.addWidget(self.header_label)
        header_layout.addStretch()
        header_layout.addWidget(self.user_label)

        self.main_layout.addLayout(header_layout)

    def create_content_area(self):
        """Create the main content area"""
        self.content_stack = QStackedWidget()
        self.main_layout.addWidget(self.content_stack)

        # Create welcome widget
        welcome_widget = QWidget()
        welcome_layout = QVBoxLayout(welcome_widget)
        
        welcome_label = QLabel('Welcome to Coffee Shop Management System')
        welcome_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        welcome_label.setStyleSheet('font-size: 20px; margin: 20px;')
        
        welcome_layout.addWidget(welcome_label)
        welcome_layout.addStretch()

        self.content_stack.addWidget(welcome_widget)

    def set_user_info(self, username, role):
        """Set the user information in the header"""
        self.user_label.setText(f'Logged in as: {username} ({role})')

    def show_error(self, message):
        """Show error message"""
        QMessageBox.critical(self, 'Error', message)

    def show_success(self, message):
        """Show success message"""
        QMessageBox.information(self, 'Success', message)

    def show_confirmation(self, message):
        """Show confirmation dialog"""
        reply = QMessageBox.question(
            self, 'Confirm Action', 
            message,
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No
        )
        return reply == QMessageBox.StandardButton.Yes

    def set_management_menu_visible(self, visible):
        """Set visibility of management menu based on user role"""
        self.management_menu.menuAction().setVisible(visible)

    def add_widget_to_stack(self, widget):
        """Add a widget to the content stack"""
        return self.content_stack.addWidget(widget)

    def show_widget(self, index):
        """Show widget at specified index in the stack"""
        self.content_stack.setCurrentIndex(index)

    def set_status_message(self, message):
        """Set status bar message"""
        self.statusBar.showMessage(message, 3000)  # Show for 3 seconds
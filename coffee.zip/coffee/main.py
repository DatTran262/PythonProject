#!/usr/bin/env python3
import sys
from PyQt6.QtWidgets import QApplication
from PyQt6.QtCore import Qt
from view.login_view import LoginView
from view.register_view import RegisterView
from controller.login_ctrl import LoginController
from controller.register_ctrl import RegisterController
from controller.main_ctrl import MainController

class CoffeeShopApp:
    def __init__(self):
        # Create the application
        self.app = QApplication(sys.argv)
        
        # Set application-wide style
        self.setup_application_style()
        
        # Create views
        self.login_view = LoginView()
        self.register_view = RegisterView()
        
        # Create controllers
        self.login_controller = LoginController(self.login_view)
        self.register_controller = RegisterController(self.register_view)
        self.main_controller = MainController(self.login_controller)
        
        # Connect login success to main window display
        self.login_view.login_successful.connect(self.show_main_window)
        
        # Connect register button to show register view
        self.login_view.register_clicked.connect(self.show_register_window)
        
        # Connect register success to close register window
        self.register_view.register_successful.connect(self.handle_registration)

    def setup_application_style(self):
        """Set up application-wide styles"""
        style = """
            QMainWindow {
                background-color: #f5f5f5;
            }
            QWidget {
                font-family: Arial, sans-serif;
            }
            QLabel {
                color: #333333;
            }
            QLineEdit {
                padding: 8px;
                border: 1px solid #ddd;
                border-radius: 4px;
                background-color: white;
            }
            QLineEdit:focus {
                border-color: #4CAF50;
            }
            QPushButton {
                background-color: #4CAF50;
                color: white;
                padding: 8px 16px;
                border: none;
                border-radius: 4px;
            }
            QPushButton:hover {
                background-color: #45a049;
            }
            QPushButton:pressed {
                background-color: #3d8b40;
            }
            QMenuBar {
                background-color: #333333;
                color: white;
            }
            QMenuBar::item {
                padding: 8px 16px;
                background-color: transparent;
                color: white;
            }
            QMenuBar::item:selected {
                background-color: #4CAF50;
            }
            QMenu {
                background-color: #ffffff;
                border: 1px solid #dddddd;
            }
            QMenu::item {
                padding: 8px 20px;
            }
            QMenu::item:selected {
                background-color: #4CAF50;
                color: white;
            }
            QStatusBar {
                background-color: #333333;
                color: white;
            }
            QMessageBox {
                background-color: #ffffff;
            }
            QMessageBox QLabel {
                color: #333333;
            }
            QMessageBox QPushButton {
                min-width: 80px;
            }
        """
        self.app.setStyleSheet(style)

    def show_main_window(self, _):
        """Show main window after successful login"""
        if self.main_controller.start():
            self.login_view.hide()
        else:
            self.login_view.show_error("Failed to initialize main window")

    def show_register_window(self):
        """Show registration window"""
        self.register_view.clear_fields()
        self.register_view.show()

    def handle_registration(self, registration_data):
        """Handle successful registration"""
        if self.register_controller.handle_register(registration_data):
            # Show success message in login view
            self.login_view.username_input.setText(registration_data['username'])
            self.login_view.password_input.clear()
            self.login_view.password_input.setFocus()

    def run(self):
        """Run the application"""
        self.login_view.show()
        return self.app.exec()

def main():
    """Application entry point"""
    # Create and run application
    coffee_shop_app = CoffeeShopApp()
    sys.exit(coffee_shop_app.run())

if __name__ == '__main__':
    main()
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import random
import string

class EmailSender:
    def __init__(self):
        # Email configuration
        self.smtp_server = "smtp.gmail.com"
        self.smtp_port = 587
        self.sender_email = "trandat262075@gmail.com"
        # Lưu ý: Cần tạo App Password từ Google Account:
        # 1. Vào Google Account Settings -> Security
        # 2. Bật 2-Step Verification nếu chưa bật
        # 3. Tạo App Password cho ứng dụng
        self.sender_password = "your-16-digit-app-password"  # Thay bằng app password từ Google
        
    def generate_otp(self, length=6):
        """Generate a random OTP"""
        return ''.join(random.choices(string.digits, k=length))
        
    def send_reset_password_email(self, to_email, otp):
        """Send password reset email with OTP"""
        try:
            # Create message
            message = MIMEMultipart()
            message["From"] = self.sender_email
            message["To"] = to_email
            message["Subject"] = "Đặt lại mật khẩu - Coffee Shop"
            
            # Email content
            body = f"""
            <html>
                <body>
                    <h2>Đặt lại mật khẩu</h2>
                    <p>Bạn đã yêu cầu đặt lại mật khẩu cho tài khoản của mình.</p>
                    <p>Mã xác thực của bạn là: <strong>{otp}</strong></p>
                    <p>Mã này sẽ hết hạn sau 5 phút.</p>
                    <p>Nếu bạn không yêu cầu đặt lại mật khẩu, vui lòng bỏ qua email này.</p>
                    <br>
                    <p>Trân trọng,</p>
                    <p>Coffee Shop Team</p>
                </body>
            </html>
            """
            
            message.attach(MIMEText(body, "html"))
            
            # Create SMTP session
            with smtplib.SMTP(self.smtp_server, self.smtp_port) as server:
                server.starttls()
                server.login(self.sender_email, self.sender_password)
                server.send_message(message)
                
            return True, "Email đã được gửi thành công"
            
        except Exception as e:
            print(f"Error sending email: {str(e)}")
            return False, f"Lỗi khi gửi email: {str(e)}"
            
    def verify_otp(self, otp, stored_otp):
        """Verify if OTP matches"""
        return otp == stored_otp
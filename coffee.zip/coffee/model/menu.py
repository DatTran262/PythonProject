from .database import Database

class MenuItem:
    def __init__(self, id=None, name=None, description=None, price=None, category=None):
        self.id = id
        self.name = name
        self.description = description
        self.price = price
        self.category = category
        self.db = Database()

    @staticmethod
    def get_all_items():
        """Get all menu items from database"""
        db = Database()
        return db.execute_query("SELECT * FROM menu_items ORDER BY category, name")

    @staticmethod
    def get_item_by_id(item_id):
        """Get menu item by ID"""
        db = Database()
        result = db.execute_query(
            "SELECT * FROM menu_items WHERE id = %s",
            (item_id,)
        )
        if result and len(result) > 0:
            item = result[0]
            return MenuItem(
                id=item['id'],
                name=item['name'],
                description=item['description'],
                price=float(item['price']),
                category=item['category']
            )
        return None

    @staticmethod
    def get_items_by_category(category):
        """Get menu items by category"""
        db = Database()
        return db.execute_query(
            "SELECT * FROM menu_items WHERE category = %s ORDER BY name",
            (category,)
        )

    def create_item(self):
        """Create a new menu item"""
        result = self.db.execute_query(
            """INSERT INTO menu_items (name, description, price, category)
            VALUES (%s, %s, %s, %s)""",
            (self.name, self.description, self.price, self.category)
        )
        if result:
            items = self.db.execute_query(
                "SELECT * FROM menu_items WHERE name = %s AND category = %s",
                (self.name, self.category)
            )
            if items:
                self.id = items[0]['id']
                return True, "Menu item created successfully"
        return False, "Failed to create menu item"

    def update_item(self):
        """Update menu item information"""
        if not self.id:
            return False, "Menu item ID is required for update"

        result = self.db.execute_query(
            """UPDATE menu_items 
            SET name = %s, description = %s, price = %s, category = %s
            WHERE id = %s""",
            (self.name, self.description, self.price, self.category, self.id)
        )
        return result is not None, "Menu item updated successfully" if result else "Failed to update menu item"

    def delete_item(self):
        """Delete menu item"""
        if not self.id:
            return False, "Menu item ID is required for deletion"

        result = self.db.execute_query(
            "DELETE FROM menu_items WHERE id = %s",
            (self.id,)
        )
        return result is not None, "Menu item deleted successfully" if result else "Failed to delete menu item"

    @staticmethod
    def get_categories():
        """Get all unique categories"""
        db = Database()
        results = db.execute_query(
            "SELECT DISTINCT category FROM menu_items ORDER BY category"
        )
        return [result['category'] for result in results] if results else []

    def to_dict(self):
        """Convert menu item object to dictionary"""
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'price': self.price,
            'category': self.category
        }
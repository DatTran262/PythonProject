from .database import Database

class User:
    def __init__(self, id=None, username=None, role=None):
        self.id = id
        self.username = username
        self.role = role
        self.db = Database()
        self.db.connect()  # Ensure connection is established

    @staticmethod
    def authenticate(username, password):
        """Authenticate user with username and password"""
        
    @staticmethod
    def find_user_by_email(email):
        """Find user by email"""
        try:
            db = Database()
            if not db.connect():
                return None
                
            print(f"Finding user by email: {email}")  # Debug log
            result = db.execute_query(
                "SELECT * FROM users WHERE email = %s",
                (email,)
            )
            
            print(f"Find by email result: {result}")  # Debug log
            
            if result and len(result) > 0:
                user_data = result[0]
                return User(
                    id=user_data['id'],
                    username=user_data['username'],
                    role=user_data['role']
                )
            return None
        except Exception as e:
            print(f"Find user by email error: {str(e)}")
            return None
            
    @staticmethod
    def find_user_by_phone(phone):
        """Find user by phone number"""
        try:
            db = Database()
            if not db.connect():
                return None
                
            print(f"Finding user by phone: {phone}")  # Debug log
            result = db.execute_query(
                "SELECT * FROM users WHERE phone = %s",
                (phone,)
            )
            
            print(f"Find by phone result: {result}")  # Debug log
            
            if result and len(result) > 0:
                user_data = result[0]
                return User(
                    id=user_data['id'],
                    username=user_data['username'],
                    role=user_data['role']
                )
            return None
        except Exception as e:
            print(f"Find user by phone error: {str(e)}")
            return None
            
    def reset_password(self, new_password):
        """Reset user's password"""
        if not self.db.connect():
            return False, "Database connection failed"
            
        result = self.db.execute_query(
            "UPDATE users SET password = %s WHERE id = %s",
            (new_password, self.id)
        )
        return result is not None, "Password reset successfully" if result else "Failed to reset password"
        try:
            db = Database()
            if not db.connect():  # Ensure connection is established
                print("Failed to connect to database during authentication")
                return None

            # Add debugging print statement
            print(f"Attempting to authenticate user: {username}")

            result = db.execute_query(
                "SELECT * FROM users WHERE username = %s AND password = %s",
                (username, password)
            )

            # Add debugging print statement
            print(f"Authentication query result: {result}")

            if result and len(result) > 0:
                user_data = result[0]
                return User(
                    id=user_data['id'],
                    username=user_data['username'],
                    role=user_data['role']
                )
            return None
        except Exception as e:
            print(f"Authentication error: {str(e)}")
            return None

    @staticmethod
    def get_all_users():
        """Get all users from database"""
        db = Database()
        if not db.connect():
            return []
        return db.execute_query("SELECT id, username, role FROM users")

    def create_user(self, username, password, role):
        """Create a new user"""
        if self.role != 'admin':
            return False, "Only administrators can create users"
        
        if not self.db.connect():
            return False, "Database connection failed"

        result = self.db.execute_query(
            "INSERT INTO users (username, password, role) VALUES (%s, %s, %s)",
            (username, password, role)
        )
        return result is not None, "User created successfully" if result else "Failed to create user"

    def update_user(self, user_id, username=None, password=None, role=None):
        """Update user information"""
        if self.role != 'admin':
            return False, "Only administrators can update users"

        if not self.db.connect():
            return False, "Database connection failed"

        updates = []
        params = []
        if username:
            updates.append("username = %s")
            params.append(username)
        if password:
            updates.append("password = %s")
            params.append(password)
        if role:
            updates.append("role = %s")
            params.append(role)
        
        if not updates:
            return False, "No updates provided"

        params.append(user_id)
        query = f"UPDATE users SET {', '.join(updates)} WHERE id = %s"
        result = self.db.execute_query(query, tuple(params))
        
        return result is not None, "User updated successfully" if result else "Failed to update user"

    def delete_user(self, user_id):
        """Delete a user"""
        if self.role != 'admin':
            return False, "Only administrators can delete users"
        
        if not self.db.connect():
            return False, "Database connection failed"

        result = self.db.execute_query(
            "DELETE FROM users WHERE id = %s",
            (user_id,)
        )
        return result is not None, "User deleted successfully" if result else "Failed to delete user"

    def change_password(self, old_password, new_password):
        """Change user's password"""
        if not self.db.connect():
            return False, "Database connection failed"

        result = self.db.execute_query(
            "UPDATE users SET password = %s WHERE id = %s AND password = %s",
            (new_password, self.id, old_password)
        )
        return result is not None, "Password changed successfully" if result else "Failed to change password"

    def to_dict(self):
        """Convert user object to dictionary"""
        return {
            'id': self.id,
            'username': self.username,
            'role': self.role
        }
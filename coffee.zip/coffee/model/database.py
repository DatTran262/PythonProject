import pymysql
from pymysql.cursors import DictCursor

class Database:
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(Database, cls).__new__(cls)
            cls._instance.connection = None
        return cls._instance

    def connect(self):
        """Establish database connection"""
        try:
            # First try to connect to MySQL server
            temp_conn = pymysql.connect(
                host="localhost",
                user="root",
                password=""
            )
            
            # Create database if it doesn't exist
            with temp_conn.cursor() as cursor:
                cursor.execute("CREATE DATABASE IF NOT EXISTS coffee_shop")
            temp_conn.close()

            # Now connect to the coffee_shop database
            self.connection = pymysql.connect(
                host="localhost",
                user="root",
                password="",
                database="coffee_shop",
                cursorclass=DictCursor
            )
            
            # Create tables immediately after connecting
            self.create_tables()
            return True
            
        except pymysql.Error as e:
            print(f"Error connecting to database: {e}")
            return False

    def disconnect(self):
        """Close database connection"""
        if self.connection:
            self.connection.close()
            self.connection = None

    def execute_query(self, query, params=None):
        """Execute a query and return results"""
        try:
            # Reconnect if connection is lost
            if not self.connection or not self.connection.open:
                if not self.connect():
                    print("Failed to reconnect to database")
                    return None

            with self.connection.cursor() as cursor:
                cursor.execute(query, params or ())
                if query.strip().upper().startswith(('SELECT', 'SHOW')):
                    result = cursor.fetchall()
                    # Add debugging print
                    print(f"Query result: {result}")
                    return result
                self.connection.commit()
                return cursor.rowcount
        except pymysql.Error as e:
            print(f"Error executing query: {e}")
            if self.connection:
                self.connection.rollback()
            return None

    def create_tables(self):
        """Create database tables if they don't exist"""
        queries = [
            """
            CREATE TABLE IF NOT EXISTS users (
                id INT AUTO_INCREMENT PRIMARY KEY,
                username VARCHAR(50) UNIQUE NOT NULL,
                password VARCHAR(255) NOT NULL,
                email VARCHAR(100) UNIQUE,
                phone VARCHAR(20) UNIQUE,
                role ENUM('admin', 'staff') NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS menu_items (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(100) NOT NULL,
                description TEXT,
                price DECIMAL(10,2) NOT NULL,
                category VARCHAR(50) NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS orders (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                total_amount DECIMAL(10,2) NOT NULL,
                status ENUM('pending', 'completed', 'cancelled') DEFAULT 'pending',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id)
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS order_items (
                id INT AUTO_INCREMENT PRIMARY KEY,
                order_id INT NOT NULL,
                menu_item_id INT NOT NULL,
                quantity INT NOT NULL,
                price_at_time DECIMAL(10,2) NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (order_id) REFERENCES orders(id),
                FOREIGN KEY (menu_item_id) REFERENCES menu_items(id)
            )
            """
        ]
        
        # Create tables
        for query in queries:
            self.execute_query(query)

        # Check if admin user exists
        result = self.execute_query(
            "SELECT * FROM users WHERE username = 'admin'"
        )
        
        # If no admin user exists, create default users
        if not result:
            print("Creating default users...")
            self.execute_query(
                "INSERT INTO users (username, password, email, phone, role) VALUES (%s, %s, %s, %s, %s)",
                ("admin", "admin123", "trandat262075@gmail.com", "0123456789", "admin")
            )
            self.execute_query(
                "INSERT INTO users (username, password, email, phone, role) VALUES (%s, %s, %s, %s, %s)",
                ("staff", "staff123", "staff@coffee.com", "0987654321", "staff")
            )
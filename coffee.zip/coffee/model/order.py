from datetime import datetime
from .database import Database
from .menu import MenuItem

class Order:
    def __init__(self, id=None, user_id=None, total_amount=0, status='pending'):
        self.id = id
        self.user_id = user_id
        self.total_amount = total_amount
        self.status = status
        self.items = []
        self.db = Database()

    @staticmethod
    def get_all_orders():
        """Get all orders from database"""
        db = Database()
        return db.execute_query(
            """SELECT o.*, u.username 
            FROM orders o 
            JOIN users u ON o.user_id = u.id 
            ORDER BY o.created_at DESC"""
        )

    @staticmethod
    def get_order_by_id(order_id):
        """Get order by ID with its items"""
        db = Database()
        order_result = db.execute_query(
            """SELECT o.*, u.username 
            FROM orders o 
            JOIN users u ON o.user_id = u.id 
            WHERE o.id = %s""",
            (order_id,)
        )
        
        if order_result and len(order_result) > 0:
            order_data = order_result[0]
            order = Order(
                id=order_data['id'],
                user_id=order_data['user_id'],
                total_amount=float(order_data['total_amount']),
                status=order_data['status']
            )
            
            items_result = db.execute_query(
                """SELECT oi.*, mi.name, mi.category 
                FROM order_items oi 
                JOIN menu_items mi ON oi.menu_item_id = mi.id 
                WHERE oi.order_id = %s""",
                (order_id,)
            )
            
            if items_result:
                order.items = items_result
            return order
        return None

    def add_item(self, menu_item_id, quantity):
        """Add item to order"""
        menu_item = MenuItem.get_item_by_id(menu_item_id)
        if not menu_item:
            return False, "Menu item not found"

        self.items.append({
            'menu_item_id': menu_item_id,
            'quantity': quantity,
            'price_at_time': menu_item.price,
            'subtotal': menu_item.price * quantity
        })
        self._update_total()
        return True, "Item added to order"

    def remove_item(self, menu_item_id):
        """Remove item from order"""
        self.items = [item for item in self.items if item['menu_item_id'] != menu_item_id]
        self._update_total()
        return True, "Item removed from order"

    def _update_total(self):
        """Update order total amount"""
        self.total_amount = sum(item['subtotal'] for item in self.items)

    def create_order(self):
        """Create new order with items"""
        if not self.items:
            return False, "Order must have at least one item"

        try:
            # Create order
            result = self.db.execute_query(
                """INSERT INTO orders (user_id, total_amount, status)
                VALUES (%s, %s, %s)""",
                (self.user_id, self.total_amount, self.status)
            )
            
            if not result:
                return False, "Failed to create order"

            # Get the new order ID
            order_data = self.db.execute_query(
                "SELECT id FROM orders WHERE user_id = %s ORDER BY created_at DESC LIMIT 1",
                (self.user_id,)
            )
            
            if not order_data:
                return False, "Failed to retrieve order ID"

            self.id = order_data[0]['id']

            # Create order items
            for item in self.items:
                result = self.db.execute_query(
                    """INSERT INTO order_items 
                    (order_id, menu_item_id, quantity, price_at_time)
                    VALUES (%s, %s, %s, %s)""",
                    (self.id, item['menu_item_id'], item['quantity'], item['price_at_time'])
                )
                if not result:
                    return False, "Failed to create order items"

            return True, "Order created successfully"
        except Exception as e:
            return False, f"Error creating order: {str(e)}"

    def update_status(self, new_status):
        """Update order status"""
        if not self.id:
            return False, "Order ID is required for status update"

        if new_status not in ['pending', 'completed', 'cancelled']:
            return False, "Invalid order status"

        result = self.db.execute_query(
            "UPDATE orders SET status = %s WHERE id = %s",
            (new_status, self.id)
        )
        if result:
            self.status = new_status
            return True, "Order status updated successfully"
        return False, "Failed to update order status"

    @staticmethod
    def get_revenue_report(start_date, end_date=None):
        """Get revenue report for a date range"""
        if not end_date:
            end_date = datetime.now().strftime('%Y-%m-%d 23:59:59')

        db = Database()
        return db.execute_query(
            """SELECT DATE(created_at) as date,
            COUNT(*) as total_orders,
            SUM(total_amount) as revenue
            FROM orders
            WHERE status = 'completed'
            AND created_at BETWEEN %s AND %s
            GROUP BY DATE(created_at)
            ORDER BY date DESC""",
            (start_date, end_date)
        )

    def to_dict(self):
        """Convert order object to dictionary"""
        return {
            'id': self.id,
            'user_id': self.user_id,
            'total_amount': self.total_amount,
            'status': self.status,
            'items': self.items
        }
from PyQt6.QtCore import QObject
from model.user import User
from model.database import Database
from view.forgot_password_view import ForgotPasswordView
from controller.forgot_password_ctrl import ForgotPasswordController

class LoginController(QObject):
    def __init__(self, view):
        """Initialize login controller"""
        super().__init__()
        self.view = view
        self.db = Database()
        
        # Connect signals
        self.view.login_successful.connect(self.handle_login)
        self.view.forgot_password_clicked.connect(self.show_forgot_password)

        # Initialize database connection
        if not self.db.connect():
            self.view.show_error("Could not connect to database. Please check your connection.")
            return

        # Create database tables if they don't exist
        self.db.create_tables()

    def handle_login(self, credentials):
        """Handle login attempt"""
        username = credentials['username']
        password = credentials['password']

        # Authenticate user
        user = User.authenticate(username, password)

        if user:
            # Store current user for later use
            self.current_user = user
            # Clear login form
            self.view.clear_fields()
            # Hide login window (main window will be shown by main controller)
            self.view.hide()
            return True
        else:
            self.view.show_error("Invalid username or password")
            self.view.password_input.clear()
            self.view.password_input.setFocus()
            return False

    def get_current_user(self):
        """Get currently logged in user"""
        return getattr(self, 'current_user', None)

    def logout(self):
        """Handle user logout"""
        self.current_user = None
        self.view.clear_fields()
        self.view.show()
        
    def show_forgot_password(self):
        """Show forgot password window"""
        self.forgot_password_view = ForgotPasswordView()
        self.forgot_password_controller = ForgotPasswordController(self.forgot_password_view)
        self.forgot_password_view.show()
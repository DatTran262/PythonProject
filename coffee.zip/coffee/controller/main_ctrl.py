from PyQt6.QtCore import QObject
from view.main_view import MainView
from model.user import User
from model.database import Database

class MainController(QObject):
    def __init__(self, login_controller):
        super().__init__()
        self.login_controller = login_controller
        self.view = MainView()
        self.db = Database()
        self.setup_connections()
        
    def setup_connections(self):
        """Setup signal/slot connections"""
        # File menu actions
        self.view.logout_action.triggered.connect(self.handle_logout)
        self.view.exit_action.triggered.connect(self.view.close)
        
        # Management menu actions
        self.view.users_action.triggered.connect(self.show_user_management)
        self.view.menu_items_action.triggered.connect(self.show_menu_management)
        
        # Orders menu actions
        self.view.new_order_action.triggered.connect(self.show_new_order)
        self.view.view_orders_action.triggered.connect(self.show_order_list)
        
        # Reports menu actions
        self.view.daily_report_action.triggered.connect(
            lambda: self.show_revenue_report('daily'))
        self.view.weekly_report_action.triggered.connect(
            lambda: self.show_revenue_report('weekly'))
        self.view.monthly_report_action.triggered.connect(
            lambda: self.show_revenue_report('monthly'))

    def start(self):
        """Initialize the main application window"""
        current_user = self.login_controller.get_current_user()
        if not current_user:
            return False

        # Set user information
        self.view.set_user_info(current_user.username, current_user.role)
        
        # Configure UI based on user role
        self.configure_permissions(current_user.role)
        
        # Show the main window
        self.view.show()
        return True

    def configure_permissions(self, role):
        """Configure UI elements based on user role"""
        # Show/hide management menu based on role
        self.view.set_management_menu_visible(role == 'admin')

    def handle_logout(self):
        """Handle user logout"""
        if self.view.show_confirmation("Are you sure you want to logout?"):
            self.view.hide()
            self.login_controller.logout()

    def show_user_management(self):
        """Show user management view"""
        # This will be implemented when we create the user management view
        pass

    def show_menu_management(self):
        """Show menu management view"""
        # This will be implemented when we create the menu management view
        pass

    def show_new_order(self):
        """Show new order view"""
        # This will be implemented when we create the order view
        pass

    def show_order_list(self):
        """Show order list view"""
        # This will be implemented when we create the order list view
        pass

    def show_revenue_report(self, period):
        """Show revenue report view"""
        # This will be implemented when we create the revenue report view
        pass

    def show_error(self, message):
        """Show error message"""
        self.view.show_error(message)

    def show_success(self, message):
        """Show success message"""
        self.view.show_success(message)

    def set_status_message(self, message):
        """Set status bar message"""
        self.view.set_status_message(message)